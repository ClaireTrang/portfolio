# 🍌 Diệu Trang — Minion-Concept Portfolio

Portfolio một trang (single-page), theme lấy cảm hứng từ **Minions** (vàng chuối, denim xanh, kính goggle), hiệu ứng chuyển cảnh nặng đô bằng GSAP + ScrollTrigger:

- Màn hình loading kiểu banana loader
- Custom cursor hình kính goggle
- Hero với hiệu ứng tách chữ (split-letter bounce) + tilt ảnh theo chuột
- Marquee chạy ngôn ngữ Minion
- Đếm số liệu (stat counter) khi cuộn tới
- **Timeline kinh nghiệm cuộn ngang có pin (horizontal pinned scroll)** — điểm nhấn chính
- Thanh kỹ năng (skill bar) tự fill khi vào khung nhìn
- Gallery cuộn ngang, hiệu ứng "wipe" khi các section xuất hiện

## Cấu trúc thư mục

```
portfolio/
├── index.html   ← TOÀN BỘ trang: HTML/CSS/JS + 7 ảnh đã nhúng base64 ngay trong file
└── README.md
```

**Quan trọng:** phiên bản này chỉ có **đúng 1 file `index.html`** — toàn bộ ảnh đã được nhúng thẳng vào file (base64) nên không còn phụ thuộc thư mục `assets/images/` nữa. Đây là cách sửa lỗi ảnh bị vỡ khi đẩy lên GitHub trước đó (do thiếu thư mục ảnh khi push). Giờ chỉ cần đúng 1 file này là ảnh luôn hiển thị, không thể thiếu sót gì được nữa.

## Cách đưa lên GitHub Pages (miễn phí)

1. Tạo repo mới trên GitHub, ví dụ `dieutrang-portfolio`.
2. Bỏ **duy nhất file `index.html`** vào repo (đổi tên đúng là `index.html`, không đổi tên khác) rồi chạy:
   ```bash
   git init
   git add index.html
   git commit -m "Init Minion portfolio"
   git branch -M main
   git remote add origin https://github.com/<username>/dieutrang-portfolio.git
   git push -u origin main
   ```
3. Vào repo trên GitHub → **Settings → Pages**.
4. Ở mục **Build and deployment**, chọn **Deploy from a branch**, Branch = `main`, folder = `/ (root)` → **Save**.
5. Sau 1–2 phút, portfolio sẽ chạy tại:
   `https://<username>.github.io/dieutrang-portfolio/`

⚠️ Lưu ý dung lượng: vì ảnh được nhúng thẳng vào file nên `index.html` nặng khoảng 3MB — vẫn tải bình thường trên GitHub Pages, chỉ hơi chậm hơn 1-2 giây so với ảnh tách file trên mạng chậm. Nếu muốn tối ưu tốc độ tải hơn về sau, có thể tách ảnh ra thư mục `assets/images/` như bản trước và nhớ `git add` luôn cả thư mục đó.

## Tuỳ chỉnh nhanh

- **Đổi màu chủ đạo**: sửa các biến trong `:root{...}` đầu file `index.html` (`--yellow`, `--denim`, `--zap`...).
- **Đổi/thêm ảnh**: bỏ ảnh mới vào `assets/images/`, cập nhật đường dẫn `src="assets/images/ten-anh.jpg"` tại card tương ứng.
- **Thêm kinh nghiệm mới**: copy nguyên khối `<article class="exp-card">...</article>` trong phần `#experience` rồi sửa nội dung — hiệu ứng cuộn ngang tự nhận thêm card.
- **Tắt hiệu ứng cuộn ngang trên mobile**: đã tự động chuyển sang cuộn dọc thường khi màn hình < 760px (xem hàm `setupExpScroll()`).

## Thư viện dùng (qua CDN, không cần cài đặt)

- [GSAP 3](https://gsap.com/) + ScrollTrigger — animation & scroll-driven effects
- Google Fonts: `Baloo 2` (display) + `Be Vietnam Pro` (nội dung, hỗ trợ tốt tiếng Việt có dấu)

Không cần build tool, không cần npm — mở thẳng `index.html` bằng trình duyệt là chạy được (một số hiệu ứng ảnh nền cần host qua GitHub Pages hoặc `Live Server` để load mượt nhất).
